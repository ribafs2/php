# GuestBook
This is a Simple Guest book with smiles and admin panel.

### Requirements

* PHP 5.6
* IIS/Apache/Nginx
* MySQL/MariaDB

### Install & Run

* Import database.sql.txt
* Configure database connection in db_config.php
* Save your password hash in config.php (alg. SHA-256)

