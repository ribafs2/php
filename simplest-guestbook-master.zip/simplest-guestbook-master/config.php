<?php

$hash_pass = "03ac67mm16f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4"; // Hash of password 1234
$redirect = ''; 

?>
